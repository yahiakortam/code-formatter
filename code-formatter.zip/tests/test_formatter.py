"""
Unit Tests for Code Formatter

This module contains unit tests for the code formatter components.
"""

import os
import sys
import unittest
import tempfile
import json

# Add the src directory to the Python path
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src'))

# Import the formatter modules
from python_formatter import PythonFormatter
from java_formatter import JavaFormatter
from code_formatter_with_config import CodeFormatter
from config import FormatterConfig


class TestPythonFormatter(unittest.TestCase):
    """Test cases for the Python formatter."""

    def setUp(self):
        """Set up the test environment."""
        self.formatter = PythonFormatter()
        self.test_code = """
def  myFunction(  arg1,arg2):
    x=arg1+arg2
    return x
"""
        self.expected_code = """
def myFunction(arg1, arg2):
    x = arg1+arg2
    return x
"""

    def test_format_code(self):
        """Test formatting Python code."""
        formatted_code = self.formatter.format_code(self.test_code)
        self.assertEqual(formatted_code.strip(), self.expected_code.strip())

    def test_check_syntax(self):
        """Test checking Python syntax."""
        result = self.formatter.check_syntax(self.test_code)
        self.assertTrue(result['valid'])
        self.assertEqual(len(result['errors']), 0)

        # Test with invalid syntax
        invalid_code = """
def myFunction(arg1, arg2)
    x = arg1 + arg2
    return x
"""
        result = self.formatter.check_syntax(invalid_code)
        self.assertFalse(result['valid'])
        self.assertGreater(len(result['errors']), 0)

    def test_suggest_naming_conventions(self):
        """Test suggesting naming conventions for Python code."""
        result = self.formatter.suggest_naming_conventions(self.test_code)
        self.assertGreater(len(result['suggestions']), 0)
        
        # Check if the function name suggestion is correct
        function_suggestion = None
        for suggestion in result['suggestions']:
            if suggestion['type'] == 'function' and suggestion['name'] == 'myFunction':
                function_suggestion = suggestion
                break
        
        self.assertIsNotNone(function_suggestion)
        self.assertEqual(function_suggestion['suggestion'], 'my_function')


class TestJavaScriptFormatter(unittest.TestCase):
    """Test cases for the JavaScript formatter."""

    def setUp(self):
        """Set up the test environment."""
        # JavaScript formatter is tested through the unified interface
        self.formatter = CodeFormatter()
        self.test_code = """
function  my_function(  arg1,arg2){
x=arg1+arg2
return x
}
"""

    def test_format_code(self):
        """Test formatting JavaScript code."""
        result = self.formatter.format_code(self.test_code, language='javascript')
        self.assertIn('formatted_code', result)
        self.assertNotEqual(result['formatted_code'], self.test_code)
        
        # Check if the formatting added proper spacing and indentation
        self.assertIn('arg1, arg2', result['formatted_code'])
        self.assertIn('x = arg1 + arg2', result['formatted_code'])

    def test_check_syntax(self):
        """Test checking JavaScript syntax."""
        result = self.formatter.format_code(self.test_code, language='javascript')
        self.assertTrue(result['syntax_valid'])
        self.assertEqual(len(result['errors']), 0)

        # Test with invalid syntax
        invalid_code = """
function my_function(arg1, arg2) {
    x = arg1 + arg2
    return x;
"""
        result = self.formatter.format_code(invalid_code, language='javascript')
        self.assertFalse(result['syntax_valid'])
        self.assertGreater(len(result['errors']), 0)

    def test_suggest_naming_conventions(self):
        """Test suggesting naming conventions for JavaScript code."""
        result = self.formatter.format_code(self.test_code, language='javascript')
        self.assertGreater(len(result['naming_suggestions']), 0)
        
        # Check if the function name suggestion is correct
        function_suggestion = None
        for suggestion in result['naming_suggestions']:
            if suggestion['type'] == 'function' and suggestion['name'] == 'my_function':
                function_suggestion = suggestion
                break
        
        self.assertIsNotNone(function_suggestion)
        self.assertEqual(function_suggestion['suggestion'], 'myFunction')


class TestJavaFormatter(unittest.TestCase):
    """Test cases for the Java formatter."""

    def setUp(self):
        """Set up the test environment."""
        # Initialize with the path to the google-java-format JAR file
        jar_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 
                               'lib', 'google-java-format-1.15.0-all-deps.jar')
        self.formatter = JavaFormatter({'formatter_path': jar_path})
        self.test_code = """
public class test_class {
    private int my_variable;

    public test_class(  int value) {
        this.my_variable=value;
    }
    
    public int GET_VALUE() {
        return this.my_variable;
    }
}
"""

    def test_format_code(self):
        """Test formatting Java code."""
        formatted_code = self.formatter.format_code(self.test_code)
        self.assertNotEqual(formatted_code, self.test_code)
        
        # Check if the formatting added proper spacing
        self.assertIn('this.my_variable = value', formatted_code)

    def test_suggest_naming_conventions(self):
        """Test suggesting naming conventions for Java code."""
        result = self.formatter.suggest_naming_conventions(self.test_code)
        self.assertGreater(len(result['suggestions']), 0)
        
        # Check if the class name suggestion is correct
        class_suggestion = None
        for suggestion in result['suggestions']:
            if suggestion['type'] == 'class' and suggestion['name'] == 'test_class':
                class_suggestion = suggestion
                break
        
        self.assertIsNotNone(class_suggestion)
        self.assertEqual(class_suggestion['suggestion'], 'TestClass')
        
        # Check if the method name suggestion is correct
        method_suggestion = None
        for suggestion in result['suggestions']:
            if suggestion['type'] == 'method' and suggestion['name'] == 'GET_VALUE':
                method_suggestion = suggestion
                break
        
        self.assertIsNotNone(method_suggestion)
        self.assertEqual(method_suggestion['suggestion'], 'getValue')


class TestConfigManager(unittest.TestCase):
    """Test cases for the configuration manager."""

    def setUp(self):
        """Set up the test environment."""
        self.config_manager = FormatterConfig()

    def test_default_config(self):
        """Test default configuration values."""
        config = self.config_manager.get_config()
        self.assertEqual(config['python']['formatter'], 'autopep8')
        self.assertEqual(config['python']['line_length'], 79)
        self.assertEqual(config['javascript']['printWidth'], 80)
        self.assertEqual(config['java']['line_length'], 100)

    def test_update_config(self):
        """Test updating configuration values."""
        # Update Python configuration
        self.config_manager.update_config('python', {'formatter': 'black', 'line_length': 88})
        config = self.config_manager.get_config('python')
        self.assertEqual(config['formatter'], 'black')
        self.assertEqual(config['line_length'], 88)
        
        # Update JavaScript configuration
        self.config_manager.update_config('javascript', {'printWidth': 100, 'tabWidth': 2})
        config = self.config_manager.get_config('javascript')
        self.assertEqual(config['printWidth'], 100)
        self.assertEqual(config['tabWidth'], 2)

    def test_save_load_config(self):
        """Test saving and loading configuration."""
        # Update configuration
        self.config_manager.update_config('python', {'formatter': 'black', 'line_length': 88})
        
        # Save configuration to a temporary file
        with tempfile.NamedTemporaryFile(suffix='.json', delete=False) as temp_file:
            config_file = temp_file.name
        
        self.config_manager.save_config(config_file)
        
        # Create a new configuration manager and load the saved configuration
        new_config_manager = FormatterConfig(config_file)
        config = new_config_manager.get_config('python')
        
        # Check if the loaded configuration matches the saved configuration
        self.assertEqual(config['formatter'], 'black')
        self.assertEqual(config['line_length'], 88)
        
        # Clean up
        os.unlink(config_file)

    def test_reset_config(self):
        """Test resetting configuration to defaults."""
        # Update configuration
        self.config_manager.update_config('python', {'formatter': 'black', 'line_length': 88})
        
        # Reset configuration
        self.config_manager.reset_to_defaults('python')
        config = self.config_manager.get_config('python')
        
        # Check if the configuration was reset to defaults
        self.assertEqual(config['formatter'], 'autopep8')
        self.assertEqual(config['line_length'], 79)


class TestUnifiedFormatter(unittest.TestCase):
    """Test cases for the unified formatter interface."""

    def setUp(self):
        """Set up the test environment."""
        self.formatter = CodeFormatter()
        
        # Test code for each language
        self.python_code = """
def  myFunction(  arg1,arg2):
    x=arg1+arg2
    return x
"""
        self.javascript_code = """
function  my_function(  arg1,arg2){
x=arg1+arg2
return x
}
"""
        self.java_code = """
public class test_class {
    private int my_variable;

    public test_class(  int value) {
        this.my_variable=value;
    }
}
"""

    def test_detect_language(self):
        """Test language detection."""
        # Test with file extensions
        self.assertEqual(self.formatter.detect_language('', 'test.py'), 'python')
        self.assertEqual(self.formatter.detect_language('', 'test.js'), 'javascript')
        self.assertEqual(self.formatter.detect_language('', 'test.java'), 'java')
        
        # Test with code content
        self.assertEqual(self.formatter.detect_language(self.java_code), 'java')

    def test_format_python(self):
        """Test formatting Python code through the unified interface."""
        result = self.formatter.format_code(self.python_code, language='python')
        self.assertIn('formatted_code', result)
        self.assertNotEqual(result['formatted_code'], self.python_code)
        self.assertEqual(result['language'], 'python')
        self.assertTrue(result['syntax_valid'])
        self.assertGreater(len(result['naming_suggestions']), 0)

    def test_format_javascript(self):
        """Test formatting JavaScript code through the unified interface."""
        result = self.formatter.format_code(self.javascript_code, language='javascript')
        self.assertIn('formatted_code', result)
        self.assertNotEqual(result['formatted_code'], self.javascript_code)
        self.assertEqual(result['language'], 'javascript')
        self.assertTrue(result['syntax_valid'])
        self.assertGreater(len(result['naming_suggestions']), 0)

    def test_format_java(self):
        """Test formatting Java code through the unified interface."""
        result = self.formatter.format_code(self.java_code, language='java')
        self.assertIn('formatted_code', result)
        self.assertNotEqual(result['formatted_code'], self.java_code)
        self.assertEqual(result['language'], 'java')
        # Java syntax check might fail due to class name not matching file name
        self.assertGreater(len(result['naming_suggestions']), 0)

    def test_update_config(self):
        """Test updating configuration through the unified interface."""
        # Update Python configuration
        self.formatter.update_config('python', {'formatter': 'black', 'line_length': 88})
        
        # Format Python code with the updated configuration
        result = self.formatter.format_code(self.python_code, language='python')
        
        # Black has different formatting style than autopep8
        self.assertIn('arg1 + arg2', result['formatted_code'])


if __name__ == '__main__':
    unittest.main()
