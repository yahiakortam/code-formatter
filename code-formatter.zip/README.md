# AI-Powered Code Formatter

A powerful code formatter that automatically formats and organizes messy code by ensuring proper indentation, removing unnecessary whitespace, and improving readability. The tool supports multiple programming languages (Python, JavaScript, and Java) and provides custom formatting rules.

## Features

- **Multi-language Support**: Format code in Python, JavaScript, and Java
- **Automatic Indentation**: Adjust indentation to match preferred style for each language
- **Whitespace Management**: Remove trailing whitespaces and unnecessary spaces
- **Line Length Control**: Ensure lines don't exceed specified character limits
- **Naming Conventions**: Get suggestions for function and variable naming based on language conventions
- **Syntax Error Checking**: Identify and report syntax errors in your code
- **Custom Configuration**: Customize formatting rules to match your preferences
- **Command-line Interface**: Format files or entire directories from the terminal
- **Web Interface**: Format code through a user-friendly web application with side-by-side comparison

## Installation

### Prerequisites

- Python 3.6 or higher
- Node.js (for JavaScript formatting)
- Java Runtime Environment (for Java formatting)

### Setup

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/code-formatter.git
   cd code-formatter
   ```

2. Install Python dependencies:
   ```
   pip install autopep8 black flask
   ```

3. Install Node.js dependencies:
   ```
   npm install prettier
   ```

4. Download Google Java Format:
   ```
   mkdir -p lib
   wget -O lib/google-java-format-1.15.0-all-deps.jar https://github.com/google/google-java-format/releases/download/v1.15.0/google-java-format-1.15.0-all-deps.jar
   ```

## Usage

### Command-line Interface

Format a single file:
```
python src/cli.py -f path/to/file.py
```

Format a directory:
```
python src/cli.py -d path/to/directory -r
```

Specify language:
```
python src/cli.py -f path/to/file.js -l javascript
```

Save to output file:
```
python src/cli.py -f path/to/file.py -o path/to/output.py
```

Check formatting without modifying:
```
python src/cli.py -f path/to/file.py --check
```

Customize formatting:
```
python src/cli.py -f path/to/file.py --python-formatter black --line-length 88 --indent-size 4
```

Save configuration:
```
python src/cli.py -f path/to/file.py --save-config my_config.json
```

Load configuration:
```
python src/cli.py -f path/to/file.py -c my_config.json
```

### Web Interface

1. Start the web server:
   ```
   python src/web_app.py
   ```

2. Open your browser and navigate to `http://localhost:5000`

3. Select your programming language, paste your code, and click "Format Code"

4. Adjust configuration options as needed

## Configuration Options

### Python

- **formatter**: Choose between `autopep8` and `black`
- **line_length**: Maximum line length (default: 79)
- **indent_size**: Number of spaces for indentation (default: 4)
- **aggressive**: Aggressiveness level for autopep8 (default: 1)

### JavaScript

- **printWidth**: Maximum line length (default: 80)
- **tabWidth**: Number of spaces for indentation (default: 2)
- **useTabs**: Use tabs instead of spaces (default: false)
- **semi**: Add semicolons (default: true)
- **singleQuote**: Use single quotes (default: false)
- **trailingComma**: Trailing commas (default: 'es5')
- **bracketSpacing**: Spaces in object literals (default: true)
- **arrowParens**: Include parentheses around a sole arrow function parameter (default: 'always')

### Java

- **line_length**: Maximum line length (default: 100)
- **indent_size**: Number of spaces for indentation (default: 2)

## Project Structure

```
code-formatter/
├── lib/
│   └── google-java-format-1.15.0-all-deps.jar
├── src/
│   ├── python_formatter.py
│   ├── javascript_formatter.js
│   ├── java_formatter.py
│   ├── code_formatter_with_config.py
│   ├── config.py
│   ├── cli.py
│   ├── web_app.py
│   ├── templates/
│   │   └── index.html
│   └── static/
├── tests/
│   └── test_formatter.py
└── README.md
```

## Running Tests

Run the unit tests:
```
python -m unittest discover tests
```

## Style Guidelines

The code formatter follows these style guidelines for each language:

### Python
- PEP 8 style guide
- 4 spaces for indentation
- 79 character line length
- snake_case for functions and variables

### JavaScript
- Prettier standards
- 2 spaces for indentation
- 80 character line length
- camelCase for functions and variables

### Java
- Google Java Style Guide
- 2 spaces for indentation
- 100 character line length
- camelCase for methods and variables, PascalCase for classes

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- [autopep8](https://github.com/hhatto/autopep8) and [black](https://github.com/psf/black) for Python formatting
- [prettier](https://prettier.io/) for JavaScript formatting
- [google-java-format](https://github.com/google/google-java-format) for Java formatting
