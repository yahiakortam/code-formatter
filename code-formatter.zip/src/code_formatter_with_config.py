"""
Unified Code Formatter Interface with Configuration Support

This module provides a unified interface for formatting code in multiple languages
with support for custom configuration options.
"""

import os
import json
import tempfile
import subprocess
from typing import Dict, Any, Optional, Union, List

# Import language-specific formatters
from python_formatter import PythonFormatter
from java_formatter import JavaFormatter
from config import FormatterConfig


class CodeFormatter:
    """
    A unified interface for formatting code in multiple languages with configuration support.
    """

    def __init__(self, config_file: Optional[str] = None):
        """
        Initialize the code formatter with configuration options.

        Args:
            config_file (str, optional): Path to a JSON configuration file.
        """
        # Initialize configuration manager
        self.config_manager = FormatterConfig(config_file)
        self.config = self.config_manager.get_config()
        
        # Set Java formatter path if not specified
        if self.config['java']['formatter_path'] is None:
            self.config['java']['formatter_path'] = os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                'lib', 'google-java-format-1.15.0-all-deps.jar'
            )
        
        # Initialize formatters
        self.python_formatter = PythonFormatter(self.config['python'])
        self.java_formatter = JavaFormatter(self.config['java'])
        # JavaScript formatter is initialized on demand

    def detect_language(self, code: str, filename: Optional[str] = None) -> str:
        """
        Detect the programming language of the given code.

        Args:
            code (str): The code to analyze.
            filename (str, optional): The filename, which may contain an extension.

        Returns:
            str: The detected language ('python', 'javascript', 'java', or 'unknown').
        """
        # Try to detect from filename extension first
        if filename:
            ext = os.path.splitext(filename)[1].lower()
            if ext in ['.py', '.pyw']:
                return 'python'
            elif ext in ['.js', '.jsx', '.ts', '.tsx']:
                return 'javascript'
            elif ext in ['.java']:
                return 'java'

        # If no filename or extension doesn't match, try to detect from code
        # This is a simple heuristic and may not be accurate in all cases
        
        # Check for Python-specific syntax
        if 'def ' in code and ':' in code and ('import ' in code or 'from ' in code):
            return 'python'
        
        # Check for Java-specific syntax
        if 'public class ' in code or 'private class ' in code or 'protected class ' in code:
            return 'java'
        if 'public static void main' in code:
            return 'java'
        
        # Check for JavaScript-specific syntax
        if 'function ' in code and '{' in code and '}' in code:
            if 'var ' in code or 'let ' in code or 'const ' in code:
                return 'javascript'
        if '=>' in code or 'export ' in code or 'import ' in code and 'from ' in code and "'" in code:
            return 'javascript'
        
        # If we can't determine the language, return unknown
        return 'unknown'

    def format_code(self, code: str, language: Optional[str] = None, filename: Optional[str] = None) -> Dict[str, Any]:
        """
        Format the given code according to the specified language.

        Args:
            code (str): The code to format.
            language (str, optional): The programming language of the code.
                If not provided, will attempt to detect from the code or filename.
            filename (str, optional): The filename, which may contain an extension.

        Returns:
            Dict[str, Any]: A dictionary containing the formatting results.
                - formatted_code (str): The formatted code.
                - language (str): The language that was used for formatting.
                - syntax_valid (bool): Whether the code is syntactically valid.
                - errors (list): List of syntax errors if any.
                - naming_suggestions (list): List of naming convention suggestions.
        """
        # Detect language if not provided and auto-detection is enabled
        if not language and self.config['general']['auto_detect_language']:
            language = self.detect_language(code, filename)
        
        # Initialize result dictionary
        result = {
            'formatted_code': code,
            'language': language,
            'syntax_valid': True,
            'errors': [],
            'naming_suggestions': []
        }
        
        # Format code based on language
        if language == 'python':
            result['formatted_code'] = self.python_formatter.format_code(code)
            
            # Check syntax if enabled
            if self.config['general']['check_syntax']:
                syntax_result = self.python_formatter.check_syntax(code)
                result['syntax_valid'] = syntax_result['valid']
                result['errors'] = syntax_result['errors']
            
            # Suggest naming conventions if enabled
            if self.config['general']['suggest_naming']:
                naming_result = self.python_formatter.suggest_naming_conventions(code)
                result['naming_suggestions'] = naming_result['suggestions']
            
        elif language == 'javascript':
            # Format JavaScript code using Node.js and the JavaScript formatter
            result['formatted_code'] = self._format_javascript(code)
            
            # Check syntax and suggest naming if enabled
            if self.config['general']['check_syntax'] or self.config['general']['suggest_naming']:
                # Create a temporary JavaScript file to run the syntax check and naming suggestions
                with tempfile.NamedTemporaryFile(suffix='.js', delete=False) as temp_file:
                    temp_file_path = temp_file.name
                    temp_file.write(code.encode('utf-8'))
                
                try:
                    # Run the JavaScript formatter's syntax check and naming suggestions
                    js_formatter_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'javascript_formatter.js')
                    js_config = json.dumps(self.config['javascript'])
                    
                    # Escape backticks in code
                    escaped_code = code.replace('`', '\\`')
                    
                    check_script = f"""
                    const JavaScriptFormatter = require('{js_formatter_path}');
                    const formatter = new JavaScriptFormatter({js_config});
                    
                    const code = `{escaped_code}`;
                    
                    const syntaxResult = formatter.checkSyntax(code);
                    const namingResult = formatter.suggestNamingConventions(code);
                    
                    console.log(JSON.stringify({{"syntax": syntaxResult, "naming": namingResult}}));
                    """
                    
                    with tempfile.NamedTemporaryFile(suffix='.js', delete=False) as script_file:
                        script_file_path = script_file.name
                        script_file.write(check_script.encode('utf-8'))
                    
                    process = subprocess.run(['node', script_file_path], capture_output=True, text=True)
                    if process.returncode == 0:
                        js_result = json.loads(process.stdout)
                        
                        if self.config['general']['check_syntax']:
                            result['syntax_valid'] = js_result['syntax']['valid']
                            result['errors'] = js_result['syntax']['errors']
                        
                        if self.config['general']['suggest_naming']:
                            result['naming_suggestions'] = js_result['naming']['suggestions']
                    else:
                        print(f"Error checking JavaScript syntax: {process.stderr}")
                except Exception as e:
                    print(f"Error in JavaScript syntax check: {e}")
                finally:
                    # Clean up temporary files
                    if os.path.exists(temp_file_path):
                        os.unlink(temp_file_path)
                    if os.path.exists(script_file_path):
                        os.unlink(script_file_path)
            
        elif language == 'java':
            result['formatted_code'] = self.java_formatter.format_code(code)
            
            # Check syntax if enabled
            if self.config['general']['check_syntax']:
                syntax_result = self.java_formatter.check_syntax(code)
                result['syntax_valid'] = syntax_result['valid']
                result['errors'] = syntax_result['errors']
            
            # Suggest naming conventions if enabled
            if self.config['general']['suggest_naming']:
                naming_result = self.java_formatter.suggest_naming_conventions(code)
                result['naming_suggestions'] = naming_result['suggestions']
            
        else:
            # If language is unknown, return the original code with an error
            result['syntax_valid'] = False
            result['errors'].append({
                'message': f"Unsupported language: {language}"
            })
        
        return result

    def _format_javascript(self, code: str) -> str:
        """
        Format JavaScript code using Node.js and the JavaScript formatter.

        Args:
            code (str): The JavaScript code to format.

        Returns:
            str: The formatted JavaScript code.
        """
        try:
            # Create a temporary JavaScript file to run the formatter
            with tempfile.NamedTemporaryFile(suffix='.js', delete=False) as temp_file:
                temp_file_path = temp_file.name
                temp_file.write(code.encode('utf-8'))
            
            # Create a script to format the code
            js_formatter_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'javascript_formatter.js')
            js_config = json.dumps(self.config['javascript'])
            
            format_script = f"""
            const JavaScriptFormatter = require('{js_formatter_path}');
            const formatter = new JavaScriptFormatter({js_config});
            
            const fs = require('fs');
            const code = fs.readFileSync('{temp_file_path}', 'utf8');
            
            (async () => {{
                try {{
                    const formattedCode = await formatter.formatCode(code);
                    console.log(formattedCode);
                }} catch (error) {{
                    console.error('Error:', error);
                    process.exit(1);
                }}
            }})();
            """
            
            with tempfile.NamedTemporaryFile(suffix='.js', delete=False) as script_file:
                script_file_path = script_file.name
                script_file.write(format_script.encode('utf-8'))
            
            # Run the script
            process = subprocess.run(['node', script_file_path], capture_output=True, text=True)
            if process.returncode == 0:
                return process.stdout
            else:
                print(f"Error formatting JavaScript code: {process.stderr}")
                return code  # Return original code if formatting fails
        except Exception as e:
            print(f"Error in JavaScript formatting: {e}")
            return code  # Return original code if formatting fails
        finally:
            # Clean up temporary files
            if os.path.exists(temp_file_path):
                os.unlink(temp_file_path)
            if os.path.exists(script_file_path):
                os.unlink(script_file_path)

    def update_config(self, language: str, settings: Dict[str, Any]) -> bool:
        """
        Update the configuration for a specific language.

        Args:
            language (str): The language to update configuration for.
            settings (Dict[str, Any]): The new settings to apply.

        Returns:
            bool: True if the configuration was updated successfully, False otherwise.
        """
        # Update configuration using the configuration manager
        if self.config_manager.update_config(language, settings):
            # Get the updated configuration
            self.config = self.config_manager.get_config()
            
            # Reinitialize formatters with new configuration
            if language == 'python':
                self.python_formatter = PythonFormatter(self.config['python'])
            elif language == 'java':
                self.java_formatter = JavaFormatter(self.config['java'])
            # JavaScript formatter is initialized on demand
            
            return True
        return False

    def save_config(self, config_file: str) -> bool:
        """
        Save the current configuration to a JSON file.

        Args:
            config_file (str): Path to save the configuration file.

        Returns:
            bool: True if the configuration was saved successfully, False otherwise.
        """
        return self.config_manager.save_config(config_file)

    def load_config(self, config_file: str) -> bool:
        """
        Load configuration from a JSON file.

        Args:
            config_file (str): Path to a JSON configuration file.

        Returns:
            bool: True if the configuration was loaded successfully, False otherwise.
        """
        if self.config_manager.load_config(config_file):
            # Get the updated configuration
            self.config = self.config_manager.get_config()
            
            # Reinitialize formatters with new configuration
            self.python_formatter = PythonFormatter(self.config['python'])
            self.java_formatter = JavaFormatter(self.config['java'])
            # JavaScript formatter is initialized on demand
            
            return True
        return False

    def reset_config(self, language: Optional[str] = None) -> None:
        """
        Reset the configuration to default values.

        Args:
            language (str, optional): The language to reset configuration for.
                If not provided, resets the entire configuration.
        """
        self.config_manager.reset_to_defaults(language)
        self.config = self.config_manager.get_config()
        
        # Set Java formatter path if not specified or if Java config was reset
        if language is None or language == 'java':
            if self.config['java']['formatter_path'] is None:
                self.config['java']['formatter_path'] = os.path.join(
                    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                    'lib', 'google-java-format-1.15.0-all-deps.jar'
                )
        
        # Reinitialize formatters with default configuration
        if language is None or language == 'python':
            self.python_formatter = PythonFormatter(self.config['python'])
        if language is None or language == 'java':
            self.java_formatter = JavaFormatter(self.config['java'])
        # JavaScript formatter is initialized on demand


# Example usage
if __name__ == "__main__":
    # Sample code for each language
    python_code = """
def  myFunction(  arg1,arg2):
    x=arg1+arg2
    return x
"""

    javascript_code = """
function  my_function(  arg1,arg2){
x=arg1+arg2
return x
}
"""

    java_code = """
public class my_class {
    public static void HELLO_WORLD(String[] args) {
        int my_variable = 42;
        System.out.println("The answer is: " + my_variable);
    }
}
"""

    # Initialize the unified formatter with configuration
    formatter = CodeFormatter()
    
    # Format Python code
    python_result = formatter.format_code(python_code, language='python')
    print("Python Formatting Result:")
    print(python_result['formatted_code'])
    print(f"Syntax valid: {python_result['syntax_valid']}")
    print(f"Naming suggestions: {len(python_result['naming_suggestions'])}")
    
    # Update Python configuration to use black instead of autopep8
    formatter.update_config('python', {'formatter': 'black', 'line_length': 88})
    
    # Format Python code with updated configuration
    python_result_black = formatter.format_code(python_code, language='python')
    print("\nPython Formatting Result (with black):")
    print(python_result_black['formatted_code'])
    
    # Format JavaScript code
    javascript_result = formatter.format_code(javascript_code, language='javascript')
    print("\nJavaScript Formatting Result:")
    print(javascript_result['formatted_code'])
    print(f"Syntax valid: {javascript_result['syntax_valid']}")
    print(f"Naming suggestions: {len(javascript_result['naming_suggestions'])}")
    
    # Format Java code
    java_result = formatter.format_code(java_code, language='java')
    print("\nJava Formatting Result:")
    print(java_result['formatted_code'])
    print(f"Syntax valid: {java_result['syntax_valid']}")
    print(f"Naming suggestions: {len(java_result['naming_suggestions'])}")
    
    # Save configuration to a file
    config_file = 'formatter_config.json'
    if formatter.save_config(config_file):
        print(f"\nConfiguration saved to {config_file}")
    
    # Reset configuration
    formatter.reset_config()
    print("\nConfiguration reset to defaults")
