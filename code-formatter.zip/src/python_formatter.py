"""
Python Code Formatter Module

This module provides functionality to format Python code using autopep8 and black libraries.
It follows PEP 8 style guidelines and allows for custom configuration options.
"""

import autopep8
import black
from typing import Dict, Any, Optional


class PythonFormatter:
    """
    A class to format Python code using autopep8 and black libraries.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the Python formatter with configuration options.

        Args:
            config (Dict[str, Any], optional): Configuration options for the formatter.
                Supported options:
                - formatter: 'autopep8' or 'black' (default: 'autopep8')
                - line_length: Maximum line length (default: 79)
                - indent_size: Number of spaces for indentation (default: 4)
                - aggressive: Aggressiveness level for autopep8 (default: 1)
        """
        self.config = config or {}
        self.formatter = self.config.get('formatter', 'autopep8')
        self.line_length = self.config.get('line_length', 79)
        self.indent_size = self.config.get('indent_size', 4)
        self.aggressive = self.config.get('aggressive', 1)

    def format_code(self, code: str) -> str:
        """
        Format the given Python code according to the configured formatter.

        Args:
            code (str): The Python code to format.

        Returns:
            str: The formatted Python code.
        """
        if self.formatter == 'black':
            return self._format_with_black(code)
        else:
            return self._format_with_autopep8(code)

    def _format_with_autopep8(self, code: str) -> str:
        """
        Format the given Python code using autopep8.

        Args:
            code (str): The Python code to format.

        Returns:
            str: The formatted Python code.
        """
        options = {
            'max_line_length': self.line_length,
            'indent_size': self.indent_size,
            'aggressive': self.aggressive
        }
        return autopep8.fix_code(code, options=options)

    def _format_with_black(self, code: str) -> str:
        """
        Format the given Python code using black.

        Args:
            code (str): The Python code to format.

        Returns:
            str: The formatted Python code.
        """
        try:
            mode = black.Mode(
                line_length=self.line_length,
                string_normalization=True,
                preview=True
            )
            return black.format_str(code, mode=mode)
        except black.NothingChanged:
            # If black doesn't change anything, return the original code
            return code
        except Exception as e:
            # If black fails, fall back to autopep8
            print(f"Black formatting failed: {e}. Falling back to autopep8.")
            return self._format_with_autopep8(code)

    def check_syntax(self, code: str) -> Dict[str, Any]:
        """
        Check the syntax of the given Python code.

        Args:
            code (str): The Python code to check.

        Returns:
            Dict[str, Any]: A dictionary containing syntax check results.
                - valid (bool): Whether the code is syntactically valid.
                - errors (list): List of syntax errors if any.
        """
        result = {
            'valid': True,
            'errors': []
        }

        try:
            # Try to compile the code to check for syntax errors
            compile(code, '<string>', 'exec')
        except SyntaxError as e:
            result['valid'] = False
            result['errors'].append({
                'line': e.lineno,
                'column': e.offset,
                'message': str(e)
            })
        except Exception as e:
            result['valid'] = False
            result['errors'].append({
                'message': str(e)
            })

        return result

    def suggest_naming_conventions(self, code: str) -> Dict[str, Any]:
        """
        Suggest naming conventions for functions and variables in the code.

        Args:
            code (str): The Python code to analyze.

        Returns:
            Dict[str, Any]: A dictionary containing naming convention suggestions.
                - suggestions (list): List of naming suggestions.
        """
        import ast
        import re

        result = {
            'suggestions': []
        }

        try:
            tree = ast.parse(code)
            
            # Check function names
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    # Check if function name follows snake_case convention
                    if not re.match(r'^[a-z][a-z0-9_]*$', node.name):
                        snake_case = self._to_snake_case(node.name)
                        result['suggestions'].append({
                            'type': 'function',
                            'name': node.name,
                            'line': node.lineno,
                            'suggestion': snake_case,
                            'message': f"Function '{node.name}' should be renamed to '{snake_case}' to follow snake_case convention."
                        })
                
                # Check variable names
                elif isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Name):
                            # Check if variable name follows snake_case convention
                            if not re.match(r'^[a-z][a-z0-9_]*$', target.id):
                                snake_case = self._to_snake_case(target.id)
                                result['suggestions'].append({
                                    'type': 'variable',
                                    'name': target.id,
                                    'line': target.lineno,
                                    'suggestion': snake_case,
                                    'message': f"Variable '{target.id}' should be renamed to '{snake_case}' to follow snake_case convention."
                                })
        except Exception as e:
            # If AST parsing fails, return empty suggestions
            pass

        return result

    def _to_snake_case(self, name: str) -> str:
        """
        Convert a name to snake_case.

        Args:
            name (str): The name to convert.

        Returns:
            str: The name in snake_case.
        """
        import re
        # Replace camelCase with snake_case
        s1 = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', name)
        s2 = re.sub('([a-z0-9])([A-Z])', r'\1_\2', s1)
        # Convert to lowercase
        return s2.lower()


# Example usage
if __name__ == "__main__":
    # Sample unformatted Python code
    unformatted_code = '''
def  myFunction(  arg1,arg2):
    x=arg1+arg2
    return x
'''

    # Format with default settings (autopep8)
    formatter = PythonFormatter()
    formatted_code = formatter.format_code(unformatted_code)
    print("Formatted with autopep8:")
    print(formatted_code)

    # Format with black
    formatter = PythonFormatter({'formatter': 'black'})
    formatted_code = formatter.format_code(unformatted_code)
    print("\nFormatted with black:")
    print(formatted_code)

    # Check syntax
    syntax_result = formatter.check_syntax(unformatted_code)
    print("\nSyntax check result:")
    print(syntax_result)

    # Suggest naming conventions
    naming_result = formatter.suggest_naming_conventions(unformatted_code)
    print("\nNaming convention suggestions:")
    print(naming_result)
