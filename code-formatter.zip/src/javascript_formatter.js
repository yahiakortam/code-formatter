/**
 * JavaScript Code Formatter Module
 * 
 * This module provides functionality to format JavaScript code using the prettier library.
 * It follows Prettier standards for formatting and allows for custom configuration options.
 */

const prettier = require('prettier');
const fs = require('fs');

class JavaScriptFormatter {
  /**
   * Initialize the JavaScript formatter with configuration options.
   * 
   * @param {Object} config - Configuration options for the formatter
   *   Supported options:
   *   - printWidth: Maximum line length (default: 80)
   *   - tabWidth: Number of spaces for indentation (default: 2)
   *   - useTabs: Use tabs instead of spaces (default: false)
   *   - semi: Add semicolons (default: true)
   *   - singleQuote: Use single quotes (default: false)
   *   - trailingComma: Trailing commas (default: 'es5')
   *   - bracketSpacing: Spaces in object literals (default: true)
   *   - arrowParens: Include parentheses around a sole arrow function parameter (default: 'always')
   */
  constructor(config = {}) {
    this.config = {
      printWidth: config.printWidth || 80,
      tabWidth: config.tabWidth || 2,
      useTabs: config.useTabs || false,
      semi: config.semi !== undefined ? config.semi : true,
      singleQuote: config.singleQuote || false,
      trailingComma: config.trailingComma || 'es5',
      bracketSpacing: config.bracketSpacing !== undefined ? config.bracketSpacing : true,
      arrowParens: config.arrowParens || 'always',
      parser: 'babel'
    };
  }

  /**
   * Format the given JavaScript code according to the configured options.
   * 
   * @param {string} code - The JavaScript code to format
   * @returns {Promise<string>} A promise that resolves to the formatted JavaScript code
   */
  async formatCode(code) {
    try {
      return await prettier.format(code, this.config);
    } catch (error) {
      console.error('Error formatting JavaScript code:', error);
      return code; // Return original code if formatting fails
    }
  }

  /**
   * Format the given JavaScript code synchronously (for simpler usage).
   * Note: This is a wrapper that handles the promise internally.
   * 
   * @param {string} code - The JavaScript code to format
   * @returns {string} The formatted JavaScript code or original if formatting fails
   */
  formatCodeSync(code) {
    try {
      // Use prettier.format with { sync: true } option if available in your prettier version
      // Otherwise, this is a best-effort synchronous wrapper
      return prettier.format(code, { ...this.config });
    } catch (error) {
      console.error('Error formatting JavaScript code synchronously:', error);
      return code; // Return original code if formatting fails
    }
  }

  /**
   * Check the syntax of the given JavaScript code.
   * 
   * @param {string} code - The JavaScript code to check
   * @returns {Object} A dictionary containing syntax check results
   *   - valid {boolean}: Whether the code is syntactically valid
   *   - errors {Array}: List of syntax errors if any
   */
  checkSyntax(code) {
    const result = {
      valid: true,
      errors: []
    };

    try {
      // Try to parse the code to check for syntax errors
      new Function(code);
    } catch (error) {
      result.valid = false;
      
      // Extract line and column information from error message
      const match = error.message.match(/line (\d+)/);
      const line = match ? parseInt(match[1], 10) : null;
      
      result.errors.push({
        line: line,
        message: error.message
      });
    }

    return result;
  }

  /**
   * Suggest naming conventions for functions and variables in the code.
   * 
   * @param {string} code - The JavaScript code to analyze
   * @returns {Object} A dictionary containing naming convention suggestions
   *   - suggestions {Array}: List of naming suggestions
   */
  suggestNamingConventions(code) {
    const result = {
      suggestions: []
    };

    try {
      // Use a simple regex-based approach to find function and variable declarations
      // This is a simplified implementation and might not catch all cases
      
      // Find function declarations
      const functionRegex = /function\s+([a-zA-Z_$][a-zA-Z0-9_$]*)/g;
      let match;
      
      while ((match = functionRegex.exec(code)) !== null) {
        const functionName = match[1];
        if (!this._isCamelCase(functionName)) {
          const camelCase = this._toCamelCase(functionName);
          result.suggestions.push({
            type: 'function',
            name: functionName,
            suggestion: camelCase,
            message: `Function '${functionName}' should be renamed to '${camelCase}' to follow camelCase convention.`
          });
        }
      }
      
      // Find variable declarations
      const varRegex = /(?:var|let|const)\s+([a-zA-Z_$][a-zA-Z0-9_$]*)/g;
      
      while ((match = varRegex.exec(code)) !== null) {
        const varName = match[1];
        if (!this._isCamelCase(varName)) {
          const camelCase = this._toCamelCase(varName);
          result.suggestions.push({
            type: 'variable',
            name: varName,
            suggestion: camelCase,
            message: `Variable '${varName}' should be renamed to '${camelCase}' to follow camelCase convention.`
          });
        }
      }
    } catch (error) {
      console.error('Error analyzing naming conventions:', error);
    }

    return result;
  }

  /**
   * Check if a name follows camelCase convention.
   * 
   * @param {string} name - The name to check
   * @returns {boolean} Whether the name follows camelCase convention
   */
  _isCamelCase(name) {
    // First character should be lowercase letter
    // No underscores or hyphens
    // No consecutive uppercase letters (except for constants which are all uppercase)
    if (/^[A-Z]+$/.test(name)) {
      return true; // All uppercase is allowed for constants
    }
    return /^[a-z][a-zA-Z0-9]*$/.test(name);
  }

  /**
   * Convert a name to camelCase.
   * 
   * @param {string} name - The name to convert
   * @returns {string} The name in camelCase
   */
  _toCamelCase(name) {
    // Handle snake_case
    if (name.includes('_')) {
      return name
        .split('_')
        .map((part, index) => {
          if (index === 0) {
            return part.toLowerCase();
          }
          return part.charAt(0).toUpperCase() + part.slice(1).toLowerCase();
        })
        .join('');
    }
    
    // Handle kebab-case
    if (name.includes('-')) {
      return name
        .split('-')
        .map((part, index) => {
          if (index === 0) {
            return part.toLowerCase();
          }
          return part.charAt(0).toUpperCase() + part.slice(1).toLowerCase();
        })
        .join('');
    }
    
    // Handle PascalCase
    if (/^[A-Z]/.test(name)) {
      return name.charAt(0).toLowerCase() + name.slice(1);
    }
    
    return name;
  }
}

// Example usage with async/await
if (require.main === module) {
  // Sample unformatted JavaScript code
  const unformattedCode = `
function  my_function(  arg1,arg2){
x=arg1+arg2
return x
}
  `;

  // Using async IIFE (Immediately Invoked Function Expression) to handle async code
  (async () => {
    try {
      // Format with default settings
      const formatter = new JavaScriptFormatter();
      const formattedCode = await formatter.formatCode(unformattedCode);
      console.log("Formatted JavaScript code:");
      console.log(formattedCode);

      // Check syntax
      const syntaxResult = formatter.checkSyntax(unformattedCode);
      console.log("\nSyntax check result:");
      console.log(JSON.stringify(syntaxResult, null, 2));

      // Suggest naming conventions
      const namingResult = formatter.suggestNamingConventions(unformattedCode);
      console.log("\nNaming convention suggestions:");
      console.log(JSON.stringify(namingResult, null, 2));
    } catch (error) {
      console.error("Error in formatter example:", error);
    }
  })();
}

module.exports = JavaScriptFormatter;
