"""
Configuration Module for Code Formatter

This module provides functionality to manage configuration options for the code formatter.
It allows users to create, load, save, and update configuration settings.
"""

import os
import json
from typing import Dict, Any, Optional


class FormatterConfig:
    """
    A class to manage configuration options for the code formatter.
    """

    def __init__(self, config_file: Optional[str] = None):
        """
        Initialize the configuration manager.

        Args:
            config_file (str, optional): Path to a JSON configuration file.
        """
        # Default configuration
        self.config = {
            'python': {
                'formatter': 'autopep8',  # 'autopep8' or 'black'
                'line_length': 79,
                'indent_size': 4,
                'aggressive': 1
            },
            'javascript': {
                'printWidth': 80,
                'tabWidth': 2,
                'useTabs': False,
                'semi': True,
                'singleQuote': False,
                'trailingComma': 'es5',
                'bracketSpacing': True,
                'arrowParens': 'always'
            },
            'java': {
                'line_length': 100,
                'indent_size': 2,
                'formatter_path': None  # Will be set by the formatter
            },
            'general': {
                'auto_detect_language': True,
                'check_syntax': True,
                'suggest_naming': True
            }
        }

        # Load configuration from file if provided
        if config_file and os.path.exists(config_file):
            self.load_config(config_file)

    def load_config(self, config_file: str) -> bool:
        """
        Load configuration from a JSON file.

        Args:
            config_file (str): Path to a JSON configuration file.

        Returns:
            bool: True if the configuration was loaded successfully, False otherwise.
        """
        try:
            with open(config_file, 'r') as f:
                user_config = json.load(f)
            
            # Update configuration with user settings
            for lang, settings in user_config.items():
                if lang in self.config:
                    self.config[lang].update(settings)
            
            return True
        except Exception as e:
            print(f"Error loading configuration file: {e}")
            print("Using default configuration.")
            return False

    def save_config(self, config_file: str) -> bool:
        """
        Save the current configuration to a JSON file.

        Args:
            config_file (str): Path to save the configuration file.

        Returns:
            bool: True if the configuration was saved successfully, False otherwise.
        """
        try:
            with open(config_file, 'w') as f:
                json.dump(self.config, f, indent=4)
            return True
        except Exception as e:
            print(f"Error saving configuration file: {e}")
            return False

    def update_config(self, language: str, settings: Dict[str, Any]) -> bool:
        """
        Update the configuration for a specific language.

        Args:
            language (str): The language to update configuration for.
            settings (Dict[str, Any]): The new settings to apply.

        Returns:
            bool: True if the configuration was updated successfully, False otherwise.
        """
        if language not in self.config:
            print(f"Unsupported language: {language}")
            return False
        
        try:
            # Update configuration
            self.config[language].update(settings)
            return True
        except Exception as e:
            print(f"Error updating configuration: {e}")
            return False

    def get_config(self, language: Optional[str] = None) -> Dict[str, Any]:
        """
        Get the configuration for a specific language or all languages.

        Args:
            language (str, optional): The language to get configuration for.
                If not provided, returns the entire configuration.

        Returns:
            Dict[str, Any]: The configuration settings.
        """
        if language:
            if language not in self.config:
                print(f"Unsupported language: {language}")
                return {}
            return self.config[language]
        return self.config

    def reset_to_defaults(self, language: Optional[str] = None) -> None:
        """
        Reset the configuration to default values.

        Args:
            language (str, optional): The language to reset configuration for.
                If not provided, resets the entire configuration.
        """
        default_config = FormatterConfig()
        
        if language:
            if language not in self.config:
                print(f"Unsupported language: {language}")
                return
            self.config[language] = default_config.config[language]
        else:
            self.config = default_config.config


# Example usage
if __name__ == "__main__":
    # Create a configuration manager
    config_manager = FormatterConfig()
    
    # Print the default configuration
    print("Default Configuration:")
    print(json.dumps(config_manager.get_config(), indent=2))
    
    # Update the Python configuration
    python_settings = {
        'formatter': 'black',
        'line_length': 88
    }
    config_manager.update_config('python', python_settings)
    
    # Print the updated Python configuration
    print("\nUpdated Python Configuration:")
    print(json.dumps(config_manager.get_config('python'), indent=2))
    
    # Save the configuration to a file
    config_file = 'formatter_config.json'
    if config_manager.save_config(config_file):
        print(f"\nConfiguration saved to {config_file}")
    
    # Reset the Python configuration to defaults
    config_manager.reset_to_defaults('python')
    
    # Print the reset Python configuration
    print("\nReset Python Configuration:")
    print(json.dumps(config_manager.get_config('python'), indent=2))
