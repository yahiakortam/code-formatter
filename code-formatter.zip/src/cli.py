#!/usr/bin/env python3
"""
Command Line Interface for Code Formatter

This module provides a command-line interface for the code formatter.
It allows users to format code files, check syntax, and manage configuration.
"""

import os
import sys
import argparse
import json
from typing import Optional, Dict, Any, List

# Import the code formatter
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from code_formatter_with_config import CodeFormatter


def format_file(formatter: CodeFormatter, file_path: str, language: Optional[str] = None,
                output_file: Optional[str] = None, check_only: bool = False) -> bool:
    """
    Format a code file and optionally save the result to an output file.

    Args:
        formatter (CodeFormatter): The code formatter instance.
        file_path (str): Path to the input file.
        language (str, optional): The programming language of the code.
        output_file (str, optional): Path to save the formatted code.
        check_only (bool): Whether to only check if the file needs formatting.

    Returns:
        bool: True if formatting was successful or no formatting needed, False otherwise.
    """
    try:
        # Read the input file
        with open(file_path, 'r') as f:
            code = f.read()
        
        # Detect language from file extension if not provided
        if not language:
            _, ext = os.path.splitext(file_path)
            if ext in ['.py', '.pyw']:
                language = 'python'
            elif ext in ['.js', '.jsx', '.ts', '.tsx']:
                language = 'javascript'
            elif ext in ['.java']:
                language = 'java'
        
        # Format the code
        result = formatter.format_code(code, language=language, filename=file_path)
        
        # Check if the code is already formatted
        if code == result['formatted_code']:
            print(f"File {file_path} is already formatted.")
            return True
        
        # If check_only is True, just report that the file needs formatting
        if check_only:
            print(f"File {file_path} needs formatting.")
            return False
        
        # Save the formatted code
        if output_file:
            with open(output_file, 'w') as f:
                f.write(result['formatted_code'])
            print(f"Formatted code saved to {output_file}")
        else:
            with open(file_path, 'w') as f:
                f.write(result['formatted_code'])
            print(f"File {file_path} formatted successfully.")
        
        # Print syntax check results if there are errors
        if not result['syntax_valid']:
            print(f"Warning: Syntax errors found in {file_path}:")
            for error in result['errors']:
                if 'line' in error and error['line'] is not None:
                    print(f"  Line {error['line']}: {error['message']}")
                else:
                    print(f"  {error['message']}")
        
        # Print naming convention suggestions
        if result['naming_suggestions']:
            print(f"Naming convention suggestions for {file_path}:")
            for suggestion in result['naming_suggestions']:
                print(f"  {suggestion['type'].capitalize()} '{suggestion['name']}' should be renamed to '{suggestion['suggestion']}'")
        
        return True
    except Exception as e:
        print(f"Error formatting file {file_path}: {e}")
        return False


def format_directory(formatter: CodeFormatter, directory: str, language: Optional[str] = None,
                    recursive: bool = False, check_only: bool = False) -> bool:
    """
    Format all code files in a directory.

    Args:
        formatter (CodeFormatter): The code formatter instance.
        directory (str): Path to the directory.
        language (str, optional): The programming language of the code.
        recursive (bool): Whether to recursively format files in subdirectories.
        check_only (bool): Whether to only check if files need formatting.

    Returns:
        bool: True if all files were formatted successfully, False otherwise.
    """
    success = True
    
    # Get all files in the directory
    for root, dirs, files in os.walk(directory):
        # Skip subdirectories if not recursive
        if root != directory and not recursive:
            continue
        
        for file in files:
            file_path = os.path.join(root, file)
            
            # Skip non-code files
            _, ext = os.path.splitext(file_path)
            if ext not in ['.py', '.pyw', '.js', '.jsx', '.ts', '.tsx', '.java']:
                continue
            
            # Format the file
            if not format_file(formatter, file_path, language, check_only=check_only):
                success = False
    
    return success


def main():
    """
    Main entry point for the command-line interface.
    """
    parser = argparse.ArgumentParser(description='Format code according to style guidelines.')
    
    # Input options
    input_group = parser.add_mutually_exclusive_group(required=True)
    input_group.add_argument('-f', '--file', help='Path to the input file')
    input_group.add_argument('-d', '--directory', help='Path to the directory containing code files')
    
    # Output options
    parser.add_argument('-o', '--output', help='Path to the output file (only for single file)')
    
    # Language options
    parser.add_argument('-l', '--language', choices=['python', 'javascript', 'java'],
                        help='Programming language of the code')
    
    # Configuration options
    parser.add_argument('-c', '--config', help='Path to a JSON configuration file')
    parser.add_argument('--save-config', help='Save the current configuration to a file')
    
    # Formatting options
    parser.add_argument('--python-formatter', choices=['autopep8', 'black'],
                        help='Python formatter to use')
    parser.add_argument('--line-length', type=int,
                        help='Maximum line length')
    parser.add_argument('--indent-size', type=int,
                        help='Number of spaces for indentation')
    
    # Other options
    parser.add_argument('-r', '--recursive', action='store_true',
                        help='Recursively format files in subdirectories')
    parser.add_argument('--check', action='store_true',
                        help='Check if files need formatting without modifying them')
    
    args = parser.parse_args()
    
    # Initialize the formatter with configuration
    formatter = CodeFormatter(args.config)
    
    # Update configuration based on command-line arguments
    config_updated = False
    
    if args.python_formatter:
        formatter.update_config('python', {'formatter': args.python_formatter})
        config_updated = True
    
    if args.line_length:
        # Update line length for all languages
        formatter.update_config('python', {'line_length': args.line_length})
        formatter.update_config('javascript', {'printWidth': args.line_length})
        formatter.update_config('java', {'line_length': args.line_length})
        config_updated = True
    
    if args.indent_size:
        # Update indent size for all languages
        formatter.update_config('python', {'indent_size': args.indent_size})
        formatter.update_config('javascript', {'tabWidth': args.indent_size})
        formatter.update_config('java', {'indent_size': args.indent_size})
        config_updated = True
    
    # Save configuration if requested
    if args.save_config:
        if formatter.save_config(args.save_config):
            print(f"Configuration saved to {args.save_config}")
        else:
            print(f"Error saving configuration to {args.save_config}")
    
    # Format file or directory
    success = True
    
    if args.file:
        success = format_file(formatter, args.file, args.language, args.output, args.check)
    elif args.directory:
        success = format_directory(formatter, args.directory, args.language, args.recursive, args.check)
    
    # Return exit code
    sys.exit(0 if success else 1)


if __name__ == '__main__':
    main()
