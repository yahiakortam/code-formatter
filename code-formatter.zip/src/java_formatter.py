"""
Java Code Formatter Module

This module provides functionality to format Java code using google-java-format.
It follows Google Java Style Guide and allows for custom configuration options.
"""

import subprocess
import os
import re
import tempfile
from typing import Dict, Any, Optional, List


class JavaFormatter:
    """
    A class to format Java code using google-java-format.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the Java formatter with configuration options.

        Args:
            config (Dict[str, Any], optional): Configuration options for the formatter.
                Supported options:
                - line_length: Maximum line length (default: 100)
                - indent_size: Number of spaces for indentation (default: 2)
                - formatter_path: Path to the google-java-format JAR file
        """
        self.config = config or {}
        self.line_length = self.config.get('line_length', 100)
        self.indent_size = self.config.get('indent_size', 2)
        
        # Path to the google-java-format JAR file
        self.formatter_path = self.config.get(
            'formatter_path', 
            os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 
                        'lib', 'google-java-format-1.15.0-all-deps.jar')
        )
        
        # Verify that the formatter JAR file exists
        if not os.path.exists(self.formatter_path):
            raise FileNotFoundError(f"Google Java Format JAR file not found at {self.formatter_path}")

    def format_code(self, code: str) -> str:
        """
        Format the given Java code according to Google Java Style Guide.

        Args:
            code (str): The Java code to format.

        Returns:
            str: The formatted Java code.
        """
        # Create a temporary file to store the code
        with tempfile.NamedTemporaryFile(suffix='.java', delete=False) as temp_file:
            temp_file.write(code.encode('utf-8'))
            temp_file_path = temp_file.name
        
        try:
            # Run google-java-format on the temporary file
            cmd = [
                'java', '-jar', self.formatter_path,
                '--aosp',  # Use Android Open Source Project style (4-space indentation)
                temp_file_path
            ]
            
            # Execute the command
            result = subprocess.run(
                cmd, 
                capture_output=True, 
                text=True, 
                check=True
            )
            
            # Return the formatted code
            return result.stdout
        except subprocess.CalledProcessError as e:
            print(f"Error formatting Java code: {e}")
            print(f"Error output: {e.stderr}")
            return code  # Return original code if formatting fails
        finally:
            # Clean up the temporary file
            os.unlink(temp_file_path)

    def check_syntax(self, code: str) -> Dict[str, Any]:
        """
        Check the syntax of the given Java code.

        Args:
            code (str): The Java code to check.

        Returns:
            Dict[str, Any]: A dictionary containing syntax check results.
                - valid (bool): Whether the code is syntactically valid.
                - errors (list): List of syntax errors if any.
        """
        result = {
            'valid': True,
            'errors': []
        }

        # Create a temporary file to store the code
        with tempfile.NamedTemporaryFile(suffix='.java', delete=False) as temp_file:
            temp_file.write(code.encode('utf-8'))
            temp_file_path = temp_file.name
        
        try:
            # Compile the Java code to check for syntax errors
            cmd = ['javac', temp_file_path]
            
            # Execute the command
            subprocess.run(cmd, capture_output=True, text=True, check=True)
        except subprocess.CalledProcessError as e:
            result['valid'] = False
            
            # Parse the error output to extract error information
            error_lines = e.stderr.strip().split('\n')
            for line in error_lines:
                # Extract line number and error message using regex
                match = re.search(r'(\w+\.java):(\d+):\s+(.+)', line)
                if match:
                    line_num = int(match.group(2))
                    message = match.group(3)
                    result['errors'].append({
                        'line': line_num,
                        'message': message
                    })
                else:
                    # If regex doesn't match, add the whole line as an error message
                    result['errors'].append({
                        'message': line
                    })
        finally:
            # Clean up the temporary file
            os.unlink(temp_file_path)

        return result

    def suggest_naming_conventions(self, code: str) -> Dict[str, Any]:
        """
        Suggest naming conventions for classes, methods, and variables in the code.

        Args:
            code (str): The Java code to analyze.

        Returns:
            Dict[str, Any]: A dictionary containing naming convention suggestions.
                - suggestions (list): List of naming suggestions.
        """
        result = {
            'suggestions': []
        }

        # Regular expressions for different Java elements
        class_regex = r'class\s+([a-zA-Z_$][a-zA-Z0-9_$]*)'
        method_regex = r'(?:public|private|protected|static|\s) +[\w\<\>\[\]]+\s+([a-zA-Z_$][a-zA-Z0-9_$]*)\s*\('
        variable_regex = r'(?:final\s+)?(?:int|String|boolean|double|float|long|char|byte|short)\s+([a-zA-Z_$][a-zA-Z0-9_$]*)\s*[;=]'
        
        # Check class names (should be PascalCase)
        for match in re.finditer(class_regex, code):
            class_name = match.group(1)
            if not self._is_pascal_case(class_name):
                pascal_case = self._to_pascal_case(class_name)
                result['suggestions'].append({
                    'type': 'class',
                    'name': class_name,
                    'suggestion': pascal_case,
                    'message': f"Class '{class_name}' should be renamed to '{pascal_case}' to follow PascalCase convention."
                })
        
        # Check method names (should be camelCase)
        for match in re.finditer(method_regex, code):
            method_name = match.group(1)
            if not self._is_camel_case(method_name):
                camel_case = self._to_camel_case(method_name)
                result['suggestions'].append({
                    'type': 'method',
                    'name': method_name,
                    'suggestion': camel_case,
                    'message': f"Method '{method_name}' should be renamed to '{camel_case}' to follow camelCase convention."
                })
        
        # Check variable names (should be camelCase)
        for match in re.finditer(variable_regex, code):
            var_name = match.group(1)
            if not self._is_camel_case(var_name):
                camel_case = self._to_camel_case(var_name)
                result['suggestions'].append({
                    'type': 'variable',
                    'name': var_name,
                    'suggestion': camel_case,
                    'message': f"Variable '{var_name}' should be renamed to '{camel_case}' to follow camelCase convention."
                })
        
        return result

    def _is_pascal_case(self, name: str) -> bool:
        """
        Check if a name follows PascalCase convention.

        Args:
            name (str): The name to check.

        Returns:
            bool: Whether the name follows PascalCase convention.
        """
        # First character should be uppercase letter
        # No underscores or hyphens
        return re.match(r'^[A-Z][a-zA-Z0-9]*$', name) is not None

    def _is_camel_case(self, name: str) -> bool:
        """
        Check if a name follows camelCase convention.

        Args:
            name (str): The name to check.

        Returns:
            bool: Whether the name follows camelCase convention.
        """
        # First character should be lowercase letter
        # No underscores or hyphens
        # No consecutive uppercase letters (except for constants which are all uppercase)
        if re.match(r'^[A-Z]+$', name):
            return True  # All uppercase is allowed for constants
        return re.match(r'^[a-z][a-zA-Z0-9]*$', name) is not None

    def _to_pascal_case(self, name: str) -> str:
        """
        Convert a name to PascalCase.

        Args:
            name (str): The name to convert.

        Returns:
            str: The name in PascalCase.
        """
        # First convert to camelCase
        camel_case = self._to_camel_case(name)
        # Then capitalize the first letter
        return camel_case[0].upper() + camel_case[1:]

    def _to_camel_case(self, name: str) -> str:
        """
        Convert a name to camelCase.

        Args:
            name (str): The name to convert.

        Returns:
            str: The name in camelCase.
        """
        # Handle snake_case
        if '_' in name:
            return ''.join(
                word.capitalize() if i > 0 else word.lower()
                for i, word in enumerate(name.split('_'))
            )
        
        # Handle kebab-case
        if '-' in name:
            return ''.join(
                word.capitalize() if i > 0 else word.lower()
                for i, word in enumerate(name.split('-'))
            )
        
        # Handle PascalCase
        if re.match(r'^[A-Z]', name):
            return name[0].lower() + name[1:]
        
        return name


# Example usage
if __name__ == "__main__":
    # Sample unformatted Java code
    unformatted_code = """
public class my_class {
    public static void HELLO_WORLD(String[] args) {
        int my_variable = 42;
        System.out.println("The answer is: " + my_variable);
    }
}
"""

    # Format with default settings
    formatter = JavaFormatter()
    
    try:
        formatted_code = formatter.format_code(unformatted_code)
        print("Formatted Java code:")
        print(formatted_code)

        # Check syntax
        syntax_result = formatter.check_syntax(unformatted_code)
        print("\nSyntax check result:")
        print(syntax_result)

        # Suggest naming conventions
        naming_result = formatter.suggest_naming_conventions(unformatted_code)
        print("\nNaming convention suggestions:")
        print(naming_result)
    except Exception as e:
        print(f"Error: {e}")
