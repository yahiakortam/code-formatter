"""
Unified Code Formatter Interface

This module provides a unified interface for formatting code in multiple languages.
It integrates the Python, JavaScript, and Java formatters into a single interface.
"""

import os
import json
from typing import Dict, Any, Optional, Union, List

# Import language-specific formatters
from python_formatter import PythonFormatter
from java_formatter import JavaFormatter
# JavaScript formatter needs to be imported differently since it's a JS module
import subprocess
import tempfile


class CodeFormatter:
    """
    A unified interface for formatting code in multiple languages.
    """

    def __init__(self, config_file: Optional[str] = None):
        """
        Initialize the code formatter with configuration options.

        Args:
            config_file (str, optional): Path to a JSON configuration file.
        """
        # Default configuration
        self.config = {
            'python': {
                'formatter': 'autopep8',
                'line_length': 79,
                'indent_size': 4,
                'aggressive': 1
            },
            'javascript': {
                'printWidth': 80,
                'tabWidth': 2,
                'useTabs': False,
                'semi': True,
                'singleQuote': False,
                'trailingComma': 'es5',
                'bracketSpacing': True,
                'arrowParens': 'always'
            },
            'java': {
                'line_length': 100,
                'indent_size': 2,
                'formatter_path': os.path.join(
                    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                    'lib', 'google-java-format-1.15.0-all-deps.jar'
                )
            }
        }

        # Load configuration from file if provided
        if config_file and os.path.exists(config_file):
            self._load_config(config_file)

        # Initialize formatters
        self.python_formatter = PythonFormatter(self.config['python'])
        self.java_formatter = JavaFormatter(self.config['java'])
        # JavaScript formatter is initialized on demand

    def _load_config(self, config_file: str) -> None:
        """
        Load configuration from a JSON file.

        Args:
            config_file (str): Path to a JSON configuration file.
        """
        try:
            with open(config_file, 'r') as f:
                user_config = json.load(f)
            
            # Update configuration with user settings
            for lang, settings in user_config.items():
                if lang in self.config:
                    self.config[lang].update(settings)
        except Exception as e:
            print(f"Error loading configuration file: {e}")
            print("Using default configuration.")

    def detect_language(self, code: str, filename: Optional[str] = None) -> str:
        """
        Detect the programming language of the given code.

        Args:
            code (str): The code to analyze.
            filename (str, optional): The filename, which may contain an extension.

        Returns:
            str: The detected language ('python', 'javascript', 'java', or 'unknown').
        """
        # Try to detect from filename extension first
        if filename:
            ext = os.path.splitext(filename)[1].lower()
            if ext in ['.py', '.pyw']:
                return 'python'
            elif ext in ['.js', '.jsx', '.ts', '.tsx']:
                return 'javascript'
            elif ext in ['.java']:
                return 'java'

        # If no filename or extension doesn't match, try to detect from code
        # This is a simple heuristic and may not be accurate in all cases
        
        # Check for Python-specific syntax
        if 'def ' in code and ':' in code and ('import ' in code or 'from ' in code):
            return 'python'
        
        # Check for Java-specific syntax
        if 'public class ' in code or 'private class ' in code or 'protected class ' in code:
            return 'java'
        if 'public static void main' in code:
            return 'java'
        
        # Check for JavaScript-specific syntax
        if 'function ' in code and '{' in code and '}' in code:
            if 'var ' in code or 'let ' in code or 'const ' in code:
                return 'javascript'
        if '=>' in code or 'export ' in code or 'import ' in code and 'from ' in code and "'" in code:
            return 'javascript'
        
        # If we can't determine the language, return unknown
        return 'unknown'

    def format_code(self, code: str, language: Optional[str] = None, filename: Optional[str] = None) -> Dict[str, Any]:
        """
        Format the given code according to the specified language.

        Args:
            code (str): The code to format.
            language (str, optional): The programming language of the code.
                If not provided, will attempt to detect from the code or filename.
            filename (str, optional): The filename, which may contain an extension.

        Returns:
            Dict[str, Any]: A dictionary containing the formatting results.
                - formatted_code (str): The formatted code.
                - language (str): The language that was used for formatting.
                - syntax_valid (bool): Whether the code is syntactically valid.
                - errors (list): List of syntax errors if any.
                - naming_suggestions (list): List of naming convention suggestions.
        """
        # Detect language if not provided
        if not language:
            language = self.detect_language(code, filename)
        
        # Initialize result dictionary
        result = {
            'formatted_code': code,
            'language': language,
            'syntax_valid': True,
            'errors': [],
            'naming_suggestions': []
        }
        
        # Format code based on language
        if language == 'python':
            result['formatted_code'] = self.python_formatter.format_code(code)
            syntax_result = self.python_formatter.check_syntax(code)
            naming_result = self.python_formatter.suggest_naming_conventions(code)
            
            result['syntax_valid'] = syntax_result['valid']
            result['errors'] = syntax_result['errors']
            result['naming_suggestions'] = naming_result['suggestions']
            
        elif language == 'javascript':
            # Format JavaScript code using Node.js and the JavaScript formatter
            result['formatted_code'] = self._format_javascript(code)
            
            # Create a temporary JavaScript file to run the syntax check and naming suggestions
            with tempfile.NamedTemporaryFile(suffix='.js', delete=False) as temp_file:
                temp_file_path = temp_file.name
                temp_file.write(code.encode('utf-8'))
            
            try:
                # Run the JavaScript formatter's syntax check
                js_formatter_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'javascript_formatter.js')
                js_config = json.dumps(self.config['javascript'])
                
                # Escape backticks in code
                escaped_code = code.replace('`', '\\`')
                
                check_script = f"""
                const JavaScriptFormatter = require('{js_formatter_path}');
                const formatter = new JavaScriptFormatter({js_config});
                
                const code = `{escaped_code}`;
                
                const syntaxResult = formatter.checkSyntax(code);
                const namingResult = formatter.suggestNamingConventions(code);
                
                console.log(JSON.stringify({{"syntax": syntaxResult, "naming": namingResult}}));
                """
                
                with tempfile.NamedTemporaryFile(suffix='.js', delete=False) as script_file:
                    script_file_path = script_file.name
                    script_file.write(check_script.encode('utf-8'))
                
                process = subprocess.run(['node', script_file_path], capture_output=True, text=True)
                if process.returncode == 0:
                    js_result = json.loads(process.stdout)
                    result['syntax_valid'] = js_result['syntax']['valid']
                    result['errors'] = js_result['syntax']['errors']
                    result['naming_suggestions'] = js_result['naming']['suggestions']
                else:
                    print(f"Error checking JavaScript syntax: {process.stderr}")
            except Exception as e:
                print(f"Error in JavaScript syntax check: {e}")
            finally:
                # Clean up temporary files
                if os.path.exists(temp_file_path):
                    os.unlink(temp_file_path)
                if os.path.exists(script_file_path):
                    os.unlink(script_file_path)
            
        elif language == 'java':
            result['formatted_code'] = self.java_formatter.format_code(code)
            syntax_result = self.java_formatter.check_syntax(code)
            naming_result = self.java_formatter.suggest_naming_conventions(code)
            
            result['syntax_valid'] = syntax_result['valid']
            result['errors'] = syntax_result['errors']
            result['naming_suggestions'] = naming_result['suggestions']
            
        else:
            # If language is unknown, return the original code with an error
            result['syntax_valid'] = False
            result['errors'].append({
                'message': f"Unsupported language: {language}"
            })
        
        return result

    def _format_javascript(self, code: str) -> str:
        """
        Format JavaScript code using Node.js and the JavaScript formatter.

        Args:
            code (str): The JavaScript code to format.

        Returns:
            str: The formatted JavaScript code.
        """
        try:
            # Create a temporary JavaScript file to run the formatter
            with tempfile.NamedTemporaryFile(suffix='.js', delete=False) as temp_file:
                temp_file_path = temp_file.name
                temp_file.write(code.encode('utf-8'))
            
            # Create a script to format the code
            js_formatter_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'javascript_formatter.js')
            js_config = json.dumps(self.config['javascript'])
            
            format_script = f"""
            const JavaScriptFormatter = require('{js_formatter_path}');
            const formatter = new JavaScriptFormatter({js_config});
            
            const fs = require('fs');
            const code = fs.readFileSync('{temp_file_path}', 'utf8');
            
            (async () => {{
                try {{
                    const formattedCode = await formatter.formatCode(code);
                    console.log(formattedCode);
                }} catch (error) {{
                    console.error('Error:', error);
                    process.exit(1);
                }}
            }})();
            """
            
            with tempfile.NamedTemporaryFile(suffix='.js', delete=False) as script_file:
                script_file_path = script_file.name
                script_file.write(format_script.encode('utf-8'))
            
            # Run the script
            process = subprocess.run(['node', script_file_path], capture_output=True, text=True)
            if process.returncode == 0:
                return process.stdout
            else:
                print(f"Error formatting JavaScript code: {process.stderr}")
                return code  # Return original code if formatting fails
        except Exception as e:
            print(f"Error in JavaScript formatting: {e}")
            return code  # Return original code if formatting fails
        finally:
            # Clean up temporary files
            if os.path.exists(temp_file_path):
                os.unlink(temp_file_path)
            if os.path.exists(script_file_path):
                os.unlink(script_file_path)

    def save_config(self, config_file: str) -> bool:
        """
        Save the current configuration to a JSON file.

        Args:
            config_file (str): Path to save the configuration file.

        Returns:
            bool: True if the configuration was saved successfully, False otherwise.
        """
        try:
            with open(config_file, 'w') as f:
                json.dump(self.config, f, indent=4)
            return True
        except Exception as e:
            print(f"Error saving configuration file: {e}")
            return False

    def update_config(self, language: str, settings: Dict[str, Any]) -> bool:
        """
        Update the configuration for a specific language.

        Args:
            language (str): The language to update configuration for.
            settings (Dict[str, Any]): The new settings to apply.

        Returns:
            bool: True if the configuration was updated successfully, False otherwise.
        """
        if language not in self.config:
            print(f"Unsupported language: {language}")
            return False
        
        try:
            # Update configuration
            self.config[language].update(settings)
            
            # Reinitialize formatters with new configuration
            if language == 'python':
                self.python_formatter = PythonFormatter(self.config['python'])
            elif language == 'java':
                self.java_formatter = JavaFormatter(self.config['java'])
            # JavaScript formatter is initialized on demand
            
            return True
        except Exception as e:
            print(f"Error updating configuration: {e}")
            return False


# Example usage
if __name__ == "__main__":
    # Sample code for each language
    python_code = """
def  myFunction(  arg1,arg2):
    x=arg1+arg2
    return x
"""

    javascript_code = """
function  my_function(  arg1,arg2){
x=arg1+arg2
return x
}
"""

    java_code = """
public class my_class {
    public static void HELLO_WORLD(String[] args) {
        int my_variable = 42;
        System.out.println("The answer is: " + my_variable);
    }
}
"""

    # Initialize the unified formatter
    formatter = CodeFormatter()
    
    # Format Python code
    python_result = formatter.format_code(python_code, language='python')
    print("Python Formatting Result:")
    print(python_result['formatted_code'])
    print(f"Syntax valid: {python_result['syntax_valid']}")
    print(f"Naming suggestions: {len(python_result['naming_suggestions'])}")
    
    # Format JavaScript code
    javascript_result = formatter.format_code(javascript_code, language='javascript')
    print("\nJavaScript Formatting Result:")
    print(javascript_result['formatted_code'])
    print(f"Syntax valid: {javascript_result['syntax_valid']}")
    print(f"Naming suggestions: {len(javascript_result['naming_suggestions'])}")
    
    # Format Java code
    java_result = formatter.format_code(java_code, language='java')
    print("\nJava Formatting Result:")
    print(java_result['formatted_code'])
    print(f"Syntax valid: {java_result['syntax_valid']}")
    print(f"Naming suggestions: {len(java_result['naming_suggestions'])}")
    
    # Test language detection
    unknown_code = "This is not a valid code in any language."
    detected_language = formatter.detect_language(unknown_code)
    print(f"\nDetected language for unknown code: {detected_language}")
    
    detected_language = formatter.detect_language(python_code)
    print(f"Detected language for Python code: {detected_language}")
    
    detected_language = formatter.detect_language(javascript_code)
    print(f"Detected language for JavaScript code: {detected_language}")
    
    detected_language = formatter.detect_language(java_code)
    print(f"Detected language for Java code: {detected_language}")
