def myFunction(arg1, arg2):
    x = arg1+arg2
    return x


class test_class:
    def __init__(self, value):
        self.value = value

    def get_VALUE(self):
        return self.value
