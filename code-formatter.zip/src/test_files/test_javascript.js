function my_function(arg1, arg2) {
  x = arg1 + arg2;
  return x;
}

class test_class {
  constructor(value) {
    this.value = value;
  }

  get_VALUE() {
    return this.value;
  }
}

