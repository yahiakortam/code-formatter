public class test_class {
    private int my_variable;

    public test_class(int value) {
        this.my_variable = value;
    }

    public int GET_VALUE() {
        return this.my_variable;
    }

    public static void HELLO_WORLD(String[] args) {
        System.out.println("Hello, World!");
    }
}
