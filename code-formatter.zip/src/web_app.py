"""
Web Interface for Code Formatter

This module provides a web interface for the code formatter using Flask.
It allows users to format code, check syntax, and manage configuration through a browser.
"""

import os
import sys
import json
from typing import Dict, Any, Optional

from flask import Flask, render_template, request, jsonify, send_from_directory

# Import the code formatter
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from code_formatter_with_config import CodeFormatter

# Initialize Flask app
app = Flask(__name__, 
            static_folder=os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static'),
            template_folder=os.path.join(os.path.dirname(os.path.abspath(__file__)), 'templates'))

# Initialize the code formatter
formatter = CodeFormatter()

@app.route('/')
def index():
    """Render the main page."""
    return render_template('index.html')

@app.route('/format', methods=['POST'])
def format_code():
    """Format code and return the result."""
    data = request.json
    code = data.get('code', '')
    language = data.get('language')
    
    if not code:
        return jsonify({'error': 'No code provided'}), 400
    
    # Format the code
    result = formatter.format_code(code, language=language)
    
    return jsonify({
        'formatted_code': result['formatted_code'],
        'language': result['language'],
        'syntax_valid': result['syntax_valid'],
        'errors': result['errors'],
        'naming_suggestions': result['naming_suggestions']
    })

@app.route('/config', methods=['GET'])
def get_config():
    """Get the current configuration."""
    return jsonify(formatter.config)

@app.route('/config', methods=['POST'])
def update_config():
    """Update the configuration."""
    data = request.json
    language = data.get('language')
    settings = data.get('settings', {})
    
    if not language or not settings:
        return jsonify({'error': 'Language and settings are required'}), 400
    
    # Update the configuration
    success = formatter.update_config(language, settings)
    
    if success:
        return jsonify({'message': f'Configuration for {language} updated successfully'})
    else:
        return jsonify({'error': f'Failed to update configuration for {language}'}), 400

@app.route('/reset-config', methods=['POST'])
def reset_config():
    """Reset the configuration to defaults."""
    data = request.json
    language = data.get('language')  # Optional
    
    # Reset the configuration
    formatter.reset_config(language)
    
    return jsonify({'message': 'Configuration reset successfully'})

@app.route('/save-config', methods=['POST'])
def save_config():
    """Save the configuration to a file."""
    data = request.json
    filename = data.get('filename', 'formatter_config.json')
    
    # Ensure the filename has .json extension
    if not filename.endswith('.json'):
        filename += '.json'
    
    # Save the configuration
    config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', filename)
    success = formatter.save_config(config_path)
    
    if success:
        return jsonify({'message': f'Configuration saved to {filename}'})
    else:
        return jsonify({'error': f'Failed to save configuration to {filename}'}), 400

if __name__ == '__main__':
    # Create static and templates directories if they don't exist
    static_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static')
    templates_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'templates')
    
    os.makedirs(static_dir, exist_ok=True)
    os.makedirs(templates_dir, exist_ok=True)
    
    # Run the Flask app
    app.run(host='0.0.0.0', port=5000, debug=True)
